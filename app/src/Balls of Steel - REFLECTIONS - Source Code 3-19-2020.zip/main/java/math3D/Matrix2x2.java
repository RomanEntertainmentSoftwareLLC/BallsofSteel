package math3D;

/**
 * Created by Roman Entertainment Software LLC on 5/19/2018.
 */

public class Matrix2x2 {
    public float[][] m = new float[2][2];

    public Matrix2x2(){

    }

    public static Matrix2x2 copy(Matrix2x2 matrix){
        Matrix2x2 result = new Matrix2x2();

        result.m[0][0] = matrix.m[0][0]; result.m[0][1] = matrix.m[0][1];
        result.m[1][0] = matrix.m[1][0]; result.m[1][1] = matrix.m[1][1];

        return result;
    }

    public static float[] convertTo1DArray(Matrix2x2 matrix){
        float[] result = new float[16];

        result[0] = matrix.m[0][0]; result[1] = matrix.m[0][1];
        result[2] = matrix.m[1][0]; result[3] = matrix.m[1][1];

        return result;
    }

    public static Matrix2x2 convertTo2DArray(float[] matrix){
        Matrix2x2 result = new Matrix2x2();

        result.m[0][0] = matrix[0]; result.m[0][1] = matrix[1];
        result.m[1][0] = matrix[2]; result.m[1][1] = matrix[3];

        return result;
    }

    public static Matrix2x2 identity(Matrix2x2 matrix){
        matrix.m[0][0] = 1f; matrix.m[0][1] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = 1f;

        return matrix;
    }

    public static Matrix2x2 scale(Matrix2x2 matrix, float x, float y){
        matrix.m[0][0] = x; matrix.m[0][1] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = y;

        return matrix;
    }

    public static Matrix2x2 multiply(Matrix2x2 output, Matrix2x2 matrixA, Matrix2x2 matrixB) {
        Matrix2x2 result = new Matrix2x2();

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                result.m[i][j] = matrixA.m[i][0] * matrixB.m[0][j] +
                                 matrixA.m[i][1] * matrixB.m[1][j];
            }
        }

        output.m[0][0] = result.m[0][0]; output.m[0][1] = result.m[0][1];
        output.m[1][0] = result.m[1][0]; output.m[1][1] = result.m[1][1];

        return output;
    }

    public static Matrix2x2 transpose(Matrix2x2 output) {

        Matrix2x2 matrix = output;

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                output.m[i][j] = matrix.m[j][i];
            }
        }
        return output;
    }

    public static float determinant(float m00, float m01, float m10, float m11){
        return (m00 * m11 - m01 * m10);

        // Correct!

        // Example:
        // 3 8    assuming m00 m01
        // 4 6             m10 m11

        // 3 * 6 - 8 * 4 = -14  or  m00 * m11 - m01 * m10
        // in a cris-cross manner.
    }
}
