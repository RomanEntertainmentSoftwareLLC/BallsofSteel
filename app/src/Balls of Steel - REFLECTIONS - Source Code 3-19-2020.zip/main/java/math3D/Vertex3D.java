package math3D;

/**
 * Created by Roman Entertainment Software LLC on 4/27/2018.
 */
public class Vertex3D {
    public float x;
    public float y;
    public float z;
    public float w;

    public Vertex3D(){

    }

    public Vertex3D(float x, float y, float z){
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = 1f;
    }

    public Vertex3D(float x, float y, float z, float w){
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = 1f;
    }

    public float dotProduct(Vector3D vector)
    {
        return x * vector.x + y * vector.y + z * vector.z;
    }

    public float dotProduct(Vertex3D vertex)
    {
        return x * vertex.x + y * vertex.y + z * vertex.z;
    }
}
