package math3D;

/**
 * Created by Roman Entertainment Software LLC on 5/19/2018.
 */

public class Matrix3x3 {

    public float[][] m = new float[3][3];

    public Matrix3x3(){

    }

    public Matrix3x3(float m00, float m01, float m02,
                     float m10, float m11, float m12,
                     float m20, float m21, float m22){
        m[0][0] = m00; m[0][1] = m01; m[0][2] = m02;
        m[1][0] = m10; m[1][1] = m11; m[1][2] = m12;
        m[2][0] = m20; m[2][1] = m21; m[2][2] = m22;
    }

    public static Matrix3x3 copy(Matrix3x3 matrix){
        Matrix3x3 result = new Matrix3x3();

        result.m[0][0] = matrix.m[0][0]; result.m[0][1] = matrix.m[0][1]; result.m[0][2] = matrix.m[0][2];
        result.m[1][0] = matrix.m[1][0]; result.m[1][1] = matrix.m[1][1]; result.m[1][2] = matrix.m[1][2];
        result.m[2][0] = matrix.m[2][0]; result.m[2][1] = matrix.m[2][1]; result.m[2][2] = matrix.m[2][2];

        return result;
    }

    public static float[] convertTo1DArray(Matrix3x3 matrix){
        float[] result = new float[16];

        result[0] = matrix.m[0][0]; result[1] = matrix.m[0][1]; result[2] = matrix.m[0][2];
        result[3] = matrix.m[1][0]; result[4] = matrix.m[1][1]; result[5] = matrix.m[1][2];
        result[6] = matrix.m[2][0]; result[7] = matrix.m[2][1]; result[8] = matrix.m[2][2];

        return result;
    }

    public static Matrix3x3 convertTo2DArray(float[] matrix){
        Matrix3x3 result = new Matrix3x3();

        result.m[0][0] = matrix[0]; result.m[0][1] = matrix[1]; result.m[0][2] = matrix[2];
        result.m[1][0] = matrix[3]; result.m[1][1] = matrix[4]; result.m[1][2] = matrix[5];
        result.m[2][0] = matrix[6]; result.m[2][1] = matrix[7]; result.m[2][2] = matrix[8];

        return result;
    }

    public static Matrix3x3 identity(Matrix3x3 matrix){
        matrix.m[0][0] = 1f; matrix.m[0][1] = 0f; matrix.m[0][2] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = 1f; matrix.m[1][2] = 0f;
        matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = 1f;

        return matrix;
    }

    public static Matrix3x3 scale(Matrix3x3 matrix, float x, float y, float z){
        matrix.m[0][0] = x; matrix.m[0][1] = 0f; matrix.m[0][2] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = y; matrix.m[1][2] = 0f;
        matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = z;

        return matrix;
    }

    public static Matrix3x3 multiply(Matrix3x3 output, Matrix3x3 matrixA, Matrix3x3 matrixB) {
        Matrix3x3 result = new Matrix3x3();

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                result.m[i][j] = matrixA.m[i][0] * matrixB.m[0][j] +
                                 matrixA.m[i][1] * matrixB.m[1][j] +
                                 matrixA.m[i][2] * matrixB.m[2][j];
            }
        }

        output.m[0][0] = result.m[0][0]; output.m[0][1] = result.m[0][1]; output.m[0][2] = result.m[0][2];
        output.m[1][0] = result.m[1][0]; output.m[1][1] = result.m[1][1]; output.m[1][2] = result.m[1][2];
        output.m[2][0] = result.m[2][0]; output.m[2][1] = result.m[2][1]; output.m[2][2] = result.m[2][2];

        return output;
    }

    public static Vector3D multiplyVector(Vector3D output, Matrix3x3 matrix, Vector3D vector){
        float x = matrix.m[0][0] * vector.x + matrix.m[1][0] * vector.y + matrix.m[2][0] * vector.z;
        float y = matrix.m[0][1] * vector.x + matrix.m[1][1] * vector.y + matrix.m[2][1] * vector.z;
        float z = matrix.m[0][2] * vector.x + matrix.m[1][2] * vector.y + matrix.m[2][2] * vector.z;

        output = new Vector3D(x, y, z);

        return output;
    }


    public static float determinant(float m00, float m01, float m02,
                                    float m10, float m11, float m12,
                                    float m20, float m21, float m22)
    {
        return m00 * Matrix2x2.determinant(m11, m12, m21, m22)  //(m11 * m22 - m12 * m21)
             - m01 * Matrix2x2.determinant(m10, m12, m20, m22)  //(m10 * m22 - m12 * m20)
             + m02 * Matrix2x2.determinant(m10, m11, m20, m21); //(m10 * m21 - m11 * m20);

        // Corrected and verified!

        // If you take the first  number m00, crossing out the first row and first column leaves the 2x2 determinant  m11 * m22 - m12 * m21
        // If you take the second number m01, crossing out the first row and second column leaves the 2x2 determinant m10 * m22 - m12 * m20
        // If you take the third  number m02, crossing out the first row and third column leaves the 2x2 determinant  m10 * m21 - m11 * m20

        // To put it all together, the first set of numbers is positive, the second set is negative (important), and the third set is positive,
        // in a back and forth manner.
    }

    public static Matrix3x3 transpose(Matrix3x3 output) {

        Matrix3x3 matrix = output;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                output.m[i][j] = matrix.m[j][i];
            }
        }
        return output;
    }

    public static Matrix3x3 inverse(float m00, float m01, float m02,
                                    float m10, float m11, float m12,
                                    float m20, float m21, float m22) {

        Matrix3x3 matrixOfMinors = new Matrix3x3();
        Matrix3x3 coFactor = new Matrix3x3();
        Matrix3x3 transposedCoFactor;
        Matrix3x3 result = new Matrix3x3();

        matrixOfMinors.m[0][0] = Matrix2x2.determinant(m11, m12, m21, m22);
        matrixOfMinors.m[0][1] = Matrix2x2.determinant(m10, m12, m20, m22);
        matrixOfMinors.m[0][2] = Matrix2x2.determinant(m10, m11, m20, m21);

        matrixOfMinors.m[1][0] = Matrix2x2.determinant(m01, m02, m21, m22);
        matrixOfMinors.m[1][1] = Matrix2x2.determinant(m00, m02, m20, m22);
        matrixOfMinors.m[1][2] = Matrix2x2.determinant(m00, m01, m20, m21);

        matrixOfMinors.m[2][0] = Matrix2x2.determinant(m01, m02, m11, m12);
        matrixOfMinors.m[2][1] = Matrix2x2.determinant(m00, m02, m10, m12);
        matrixOfMinors.m[2][2] = Matrix2x2.determinant(m00, m01, m10, m11);

        coFactor.m[0][0] =  matrixOfMinors.m[0][0];
        coFactor.m[0][1] = -matrixOfMinors.m[0][1];
        coFactor.m[0][2] =  matrixOfMinors.m[0][2];

        coFactor.m[1][0] = -matrixOfMinors.m[1][0];
        coFactor.m[1][1] =  matrixOfMinors.m[1][1];
        coFactor.m[1][2] = -matrixOfMinors.m[1][2];

        coFactor.m[2][0] =  matrixOfMinors.m[2][0];
        coFactor.m[2][1] = -matrixOfMinors.m[2][1];
        coFactor.m[2][2] =  matrixOfMinors.m[2][2];

        float determinant = Matrix3x3.determinant(m00, m01, m02,
                                                  m10, m11, m12,
                                                  m20, m21, m22);

        float oneOverDeterminant = 0.0f;

        if (determinant != 0.0f)
            oneOverDeterminant = 1.0f / determinant;

        transposedCoFactor = transpose(coFactor);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                result.m[i][j] = oneOverDeterminant * transposedCoFactor.m[i][j];
            }
        }

        return result;
    }

    public static Matrix3x3 inverse(Matrix3x3 output, Matrix3x3 matrix) {
        Matrix3x3 matrixOfMinors = new Matrix3x3();
        Matrix3x3 coFactor = new Matrix3x3();
        Matrix3x3 transposedCoFactor;
        Matrix3x3 result = new Matrix3x3();

        matrixOfMinors.m[0][0] = Matrix2x2.determinant(matrix.m[1][1], matrix.m[1][2], matrix.m[2][1], matrix.m[2][2]);
        matrixOfMinors.m[0][1] = Matrix2x2.determinant(matrix.m[1][0], matrix.m[1][2], matrix.m[2][0], matrix.m[2][2]);
        matrixOfMinors.m[0][2] = Matrix2x2.determinant(matrix.m[1][0], matrix.m[1][1], matrix.m[2][0], matrix.m[2][1]);

        matrixOfMinors.m[1][0] = Matrix2x2.determinant(matrix.m[0][1], matrix.m[0][2], matrix.m[2][1], matrix.m[2][2]);
        matrixOfMinors.m[1][1] = Matrix2x2.determinant(matrix.m[0][0], matrix.m[0][2], matrix.m[2][0], matrix.m[2][2]);
        matrixOfMinors.m[1][2] = Matrix2x2.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[2][0], matrix.m[2][1]);

        matrixOfMinors.m[2][0] = Matrix2x2.determinant(matrix.m[0][1], matrix.m[0][2], matrix.m[1][1], matrix.m[1][2]);
        matrixOfMinors.m[2][1] = Matrix2x2.determinant(matrix.m[0][0], matrix.m[0][2], matrix.m[1][0], matrix.m[1][2]);
        matrixOfMinors.m[2][2] = Matrix2x2.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[1][0], matrix.m[1][1]);

        coFactor.m[0][0] =  matrixOfMinors.m[0][0];
        coFactor.m[0][1] = -matrixOfMinors.m[0][1];
        coFactor.m[0][2] =  matrixOfMinors.m[0][2];

        coFactor.m[1][0] = -matrixOfMinors.m[1][0];
        coFactor.m[1][1] =  matrixOfMinors.m[1][1];
        coFactor.m[1][2] = -matrixOfMinors.m[1][2];

        coFactor.m[2][0] =  matrixOfMinors.m[2][0];
        coFactor.m[2][1] = -matrixOfMinors.m[2][1];
        coFactor.m[2][2] =  matrixOfMinors.m[2][2];

        float determinant = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][2],
                                                  matrix.m[1][0], matrix.m[1][1], matrix.m[1][2],
                                                  matrix.m[2][0], matrix.m[2][1], matrix.m[2][2]);

        float oneOverDeterminant = 0.0f;

        if (determinant != 0.0f)
            oneOverDeterminant = 1.0f / determinant;

        transposedCoFactor = transpose(coFactor);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                result.m[i][j] = oneOverDeterminant * transposedCoFactor.m[i][j];
            }
        }

        output.m[0][0] = result.m[0][0]; output.m[0][1] = result.m[0][1]; output.m[0][2] = result.m[0][2];
        output.m[1][0] = result.m[1][0]; output.m[1][1] = result.m[1][1]; output.m[1][2] = result.m[1][2];
        output.m[2][0] = result.m[2][0]; output.m[2][1] = result.m[2][1]; output.m[2][2] = result.m[2][2];

        return result;
    }
}