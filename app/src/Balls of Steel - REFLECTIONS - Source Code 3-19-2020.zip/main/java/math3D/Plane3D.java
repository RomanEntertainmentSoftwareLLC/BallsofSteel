package math3D;

/**
 * Created by Roman Entertainment Software LLC on 5/17/2018.
 */
public class Plane3D {
    public float a;
    public float b;
    public float c;
    public float d;

    public Vertex3D origin = new Vertex3D();
    public Vector3D normal = new Vector3D();

    public Plane3D(){

    }

    public Plane3D(Vertex3D pa, Vertex3D pb, Vertex3D pc){
        Vector3D v1 = new Vector3D(pa, pb);
        Vector3D v2 = new Vector3D(pa, pc);
        origin = pa;
        normal = new Vector3D();

        normal.createNormal(v1, v2);

        a = normal.x;
        b = normal.y;
        c = normal.z;
        d = -(normal.x * origin.x+ normal.y * origin.y + normal.z * origin.z);
    }

    public void createPlane(Vertex3D pa, Vertex3D pb, Vertex3D pc){
        Vector3D v1 = new Vector3D(pa, pb);
        Vector3D v2 = new Vector3D(pa, pc);
        origin = pa;
        normal = new Vector3D();

        normal.createNormal(v1, v2);

        a = normal.x;
        b = normal.y;
        c = normal.z;
        d = -(normal.x * origin.x + normal.y * origin.y + normal.z * origin.z);
    }

    public float signedDistanceTo(Vertex3D pointPosition) {
        return pointPosition.dotProduct(normal) + d;
    }

    public float signedDistanceTo(Vertex3D spherePosition, float radius) {
        return spherePosition.dotProduct(normal) + d + -radius;
    }

    public Vector3D reflect(Vector3D i) {
        Vector3D result = new Vector3D();

        float dotProduct = (normal.x * i.x + normal.y * i.y + normal.z * i.z);

        //reflect(I, N) = I - 2.0 * dot(N, I) * N

        result.x = i.x - 2f * dotProduct * normal.x;
        result.y = i.y - 2f * dotProduct * normal.y;
        result.z = i.z - 2f * dotProduct * normal.z;

        return result;
    }

    public boolean CheckPointInTriangle(Vertex3D point, Vertex3D pa, Vertex3D pb, Vertex3D pc) {

        Vector3D e10 = new Vector3D(pa, pb);
        Vector3D e20 = new Vector3D(pa, pc);

        float a = e10.dotProduct(e10);
        float b = e10.dotProduct(e20);
        float c = e20.dotProduct(e20);
        float ac_bb = (a * c) - (b * b);

        Vector3D vp = new Vector3D(pa, point);

        float d = vp.dotProduct(e10);
        float e = vp.dotProduct(e20);
        float x = (d * c) - (e * b);
        float y = (e * a) - (d * b);
        float z = (x + y) - ac_bb;

        return z < 0.0f && x >= 0.0f && y >= 0.0f;
    }
}
