package math3D;

/**
 * Created by Roman Entertainment Software LLC on 5/3/2018.
 */
public class Vector3D {
    public float x;
    public float y;
    public float z;
    public float w;

    public Vector3D(){

    }

    public Vector3D(float x, float y, float z){
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = 1f;
    }

    public Vector3D(float x, float y, float z, float w){
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }

    public Vector3D(Vertex3D vertexA, Vertex3D vertexB){
        this.x = vertexB.x - vertexA.x;
        this.y = vertexB.y - vertexA.y;
        this.z = vertexB.z - vertexA.z;
        this.w = 1f;
    }

    public void create(float x, float y, float z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void create(Vertex3D vertexA, Vertex3D vertexB){
        this.x = vertexB.x - vertexA.x;
        this.y = vertexB.y - vertexA.y;
        this.z = vertexB.z - vertexA.z;
        this.w = 1f;
    }

    public Vector3D set(float x, float y, float z){
        Vector3D result = new Vector3D();
        result.x = x;
        result.y = y;
        result.z = z;
        return result;
    }

    public Vector3D set(Vertex3D vertexA, Vertex3D vertexB){
        Vector3D result = new Vector3D();
        result.x = vertexB.x - vertexA.x;
        result.y = vertexB.y - vertexA.y;
        result.z = vertexB.z - vertexA.z;
        return result;
    }

    public float length()
    {
        return (float)Math.sqrt(x * x + y * y + z * z);
    }

    public float lengthSquared()
    {
        return x * x + y * y + z * z;
    }

    public void normalize()
    {
        float length = length();

        if (length != 0f){
            x /= length;
            y /= length;
            z /= length;
        }

    }

    public float dotProduct(Vector3D vector)
    {
        return x * vector.x + y * vector.y + z * vector.z;
    }

    public float dotProduct(Vertex3D vertex)
    {
        return x * vertex.x + y * vertex.y + z * vertex.z;
    }

    public Vector3D crossProduct(Vector3D vectorA, Vector3D vectorB)
    {
        Vector3D result = new Vector3D();
        result.x = vectorA.y * vectorB.z - vectorA.z * vectorB.y;
        result.y = vectorA.x * vectorB.z - vectorA.z * vectorB.x;
        result.z = vectorA.x * vectorB.y - vectorA.y * vectorB.x;
        return result;
    }

    public void createNormal(Vector3D vectorA, Vector3D vectorB)
    {
        // Cross product to B and A for openGLs right handed system
        // otherwise cross product A and B for left handed system.
        Vector3D vector = crossProduct(vectorB, vectorA);
        vector.normalize();
        this.x = vector.x;
        this.y = vector.y;
        this.z = vector.z;
    }

    public void createUnnormalizedNormal(Vector3D vectorA, Vector3D vectorB)
    {
        // Cross product to B and A for openGLs right handed system
        // otherwise cross product A and B for left handed system.
        Vector3D vector = crossProduct(vectorB, vectorA);
        this.x = vector.x;
        this.y = vector.y;
        this.z = vector.z;
    }

    public Vector3D setNormal(Vector3D vectorA, Vector3D vectorB)
    {
        // Cross product to B and A for openGLs right handed system
        // otherwise cross product A and B for left handed system.
        Vector3D vector = crossProduct(vectorB, vectorA); //Cross product to B and A for openGLs right handed system.
        vector.normalize();

        return vector;
    }
}
