package math3D;

import android.util.Log;
import romanentertainmentsoftware.ballsofsteel.MathCommon;

/**
 * Created by Roman Entertainment Software LLC on 5/3/2018.
 */

public class Matrix4x4 {

    public float[][] m = new float[4][4];

    public Matrix4x4(){

    }

    public Matrix4x4(float m00, float m01, float m02, float m03,
                     float m10, float m11, float m12, float m13,
                     float m20, float m21, float m22, float m23,
                     float m30, float m31, float m32, float m33){
        m[0][0] = m00; m[0][1] = m01; m[0][2] = m02; m[0][3] = m03;
        m[1][0] = m10; m[1][1] = m11; m[1][2] = m12; m[1][3] = m13;
        m[2][0] = m20; m[2][1] = m21; m[2][2] = m22; m[2][3] = m23;
        m[3][0] = m30; m[3][1] = m31; m[3][2] = m32; m[3][3] = m33;
    }

    public static Matrix4x4 copy(Matrix4x4 matrix){
        Matrix4x4 result = new Matrix4x4();

        result.m[0][0] = matrix.m[0][0]; result.m[0][1] = matrix.m[0][1]; result.m[0][2] = matrix.m[0][2]; result.m[0][3] = matrix.m[0][3];
        result.m[1][0] = matrix.m[1][0]; result.m[1][1] = matrix.m[1][1]; result.m[1][2] = matrix.m[1][2]; result.m[1][3] = matrix.m[1][3];
        result.m[2][0] = matrix.m[2][0]; result.m[2][1] = matrix.m[2][1]; result.m[2][2] = matrix.m[2][2]; result.m[2][3] = matrix.m[2][3];
        result.m[3][0] = matrix.m[3][0]; result.m[3][1] = matrix.m[3][1]; result.m[3][2] = matrix.m[3][2]; result.m[3][3] = matrix.m[3][3];

        return result;
    }

    public static float[] convertTo1DArray(Matrix4x4 matrix){
        float[] result = new float[16];

        result[0] = matrix.m[0][0]; result[1] = matrix.m[0][1]; result[2] = matrix.m[0][2]; result[3] = matrix.m[0][3];
        result[4] = matrix.m[1][0]; result[5] = matrix.m[1][1]; result[6] = matrix.m[1][2]; result[7] = matrix.m[1][3];
        result[8] = matrix.m[2][0]; result[9] = matrix.m[2][1]; result[10] = matrix.m[2][2]; result[11] = matrix.m[2][3];
        result[12] = matrix.m[3][0]; result[13] = matrix.m[3][1]; result[14] = matrix.m[3][2]; result[15] = matrix.m[3][3];

        return result;
    }

    public static Matrix4x4 convertTo2DArray(float[] matrix){
        Matrix4x4 result = new Matrix4x4();

        result.m[0][0] = matrix[0]; result.m[0][1] = matrix[1]; result.m[0][2] = matrix[2]; result.m[0][3] = matrix[3];
        result.m[1][0] = matrix[4]; result.m[1][1] = matrix[5]; result.m[1][2] = matrix[6]; result.m[1][3] = matrix[7];
        result.m[2][0] = matrix[8]; result.m[2][1] = matrix[9]; result.m[2][2] = matrix[10]; result.m[2][3] = matrix[11];
        result.m[3][0] = matrix[12]; result.m[3][1] = matrix[13]; result.m[3][2] = matrix[14]; result.m[3][3] = matrix[15];

        return result;
    }

    public static Matrix4x4 identity(Matrix4x4 matrix){
        matrix.m[0][0] = 1f; matrix.m[0][1] = 0f; matrix.m[0][2] = 0f; matrix.m[0][3] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = 1f; matrix.m[1][2] = 0f; matrix.m[1][3] = 0f;
        matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = 1f; matrix.m[2][3] = 0f;
        matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = 0f; matrix.m[3][3] = 1f;

        return matrix;
    }

    public static Matrix4x4 translate(Matrix4x4 matrix, float x, float y, float z){
        matrix.m[3][0] = x; matrix.m[3][1] = y; matrix.m[3][2] = z; matrix.m[3][3] = 1f;

        return matrix;
    }

    public static Matrix4x4 rotateX(Matrix4x4 matrix, float radians){
        matrix.m[0][0] = 1f; matrix.m[0][1] = 0f; matrix.m[0][2] = 0f; matrix.m[0][3] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = (float)Math.cos(radians); matrix.m[1][2] = (float)Math.sin(radians); matrix.m[1][3] = 0f;
        matrix.m[2][0] = 0f; matrix.m[2][1] = (float)-Math.sin(radians); matrix.m[2][2] = (float)Math.cos(radians); matrix.m[2][3] = 0f;
        matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = 0f; matrix.m[3][3] = 1f;

        return matrix;
    }

    public static Matrix4x4 rotateY(Matrix4x4 matrix, float radians){
        matrix.m[0][0] = (float)Math.cos(radians); matrix.m[0][1] = 0f; matrix.m[0][2] = (float)-Math.sin(radians); matrix.m[0][3] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = 1f; matrix.m[1][2] = 0f; matrix.m[1][3] = 0f;
        matrix.m[2][0] = (float)Math.sin(radians); matrix.m[2][1] = 0f; matrix.m[2][2] = (float)Math.cos(radians); matrix.m[2][3] = 0f;
        matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = 0f; matrix.m[3][3] = 1f;

        return matrix;
    }

    public static Matrix4x4 rotateZ(Matrix4x4 matrix, float radians){
        matrix.m[0][0] = (float)Math.cos(radians); matrix.m[0][1] = (float)Math.sin(radians); matrix.m[0][2] = 0f; matrix.m[0][3] = 0f;
        matrix.m[1][0] = (float)-Math.sin(radians); matrix.m[1][1] = (float)Math.cos(radians); matrix.m[1][2] = 0f; matrix.m[1][3] = 0f;
        matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = 1f; matrix.m[2][3] = 0f;
        matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = 0f; matrix.m[3][3] = 1f;

        return matrix;
    }

    public static Matrix4x4 scale(Matrix4x4 matrix, float x, float y, float z){
        matrix.m[0][0] = x; matrix.m[0][1] = 0f; matrix.m[0][2] = 0f; matrix.m[0][3] = 0f;
        matrix.m[1][0] = 0f; matrix.m[1][1] = y; matrix.m[1][2] = 0f; matrix.m[1][3] = 0f;
        matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = z; matrix.m[2][3] = 0f;
        matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = z; matrix.m[3][3] = 1f;

        return matrix;
    }

    public static Matrix4x4 multiply(Matrix4x4 output, Matrix4x4 matrixA, Matrix4x4 matrixB) {
        Matrix4x4 result = new Matrix4x4();

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                result.m[i][j] = matrixA.m[i][0] * matrixB.m[0][j] +
                                 matrixA.m[i][1] * matrixB.m[1][j] +
                                 matrixA.m[i][2] * matrixB.m[2][j] +
                                 matrixA.m[i][3] * matrixB.m[3][j];
            }
        }

        output.m[0][0] = result.m[0][0]; output.m[0][1] = result.m[0][1]; output.m[0][2] = result.m[0][2]; output.m[0][3] = result.m[0][3];
        output.m[1][0] = result.m[1][0]; output.m[1][1] = result.m[1][1]; output.m[1][2] = result.m[1][2]; output.m[1][3] = result.m[1][3];
        output.m[2][0] = result.m[2][0]; output.m[2][1] = result.m[2][1]; output.m[2][2] = result.m[2][2]; output.m[2][3] = result.m[2][3];
        output.m[3][0] = result.m[3][0]; output.m[3][1] = result.m[3][1]; output.m[3][2] = result.m[3][2]; output.m[3][3] = result.m[3][3];

        return output;
    }

    public static Vector3D multiplyVector(Vector3D output, Matrix4x4 matrix, Vector3D vector){
        float x = matrix.m[0][0] * vector.x + matrix.m[1][0] * vector.y + matrix.m[2][0] * vector.z + matrix.m[3][0] * vector.w;
        float y = matrix.m[0][1] * vector.x + matrix.m[1][1] * vector.y + matrix.m[2][1] * vector.z + matrix.m[3][1] * vector.w;
        float z = matrix.m[0][2] * vector.x + matrix.m[1][2] * vector.y + matrix.m[2][2] * vector.z + matrix.m[3][2] * vector.w;
        float w = matrix.m[0][3] * vector.x + matrix.m[1][3] * vector.y + matrix.m[2][3] * vector.z + matrix.m[3][3] * vector.w;

        output = new Vector3D(x, y, z, w);

        return output;
    }

    public static Matrix4x4 transpose(Matrix4x4 output) {

        Matrix4x4 matrix = output;

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                output.m[i][j] = matrix.m[j][i];
            }
        }
        return output;
    }

    public static float determinant(float m00, float m01, float m02, float m03,
                                    float m10, float m11, float m12, float m13,
                                    float m20, float m21, float m22, float m23,
                                    float m30, float m31, float m32, float m33) {
        float f = m00 * Matrix3x3.determinant(m11, m12, m13, m21, m22, m23, m31, m32, m33)
                - m01 * Matrix3x3.determinant(m10, m12, m13, m20, m22, m23, m30, m32, m33)
                + m02 * Matrix3x3.determinant(m10, m11, m13, m20, m21, m23, m30, m31, m33)
                - m03 * Matrix3x3.determinant(m10, m11, m12, m20, m21, m22, m30, m31, m32);

        return f;
    }

    public static float determinant(Matrix4x4 matrix) {
        float f = matrix.m[0][0] * Matrix3x3.determinant(matrix.m[1][1], matrix.m[1][2], matrix.m[1][3], matrix.m[2][1], matrix.m[2][2], matrix.m[2][3], matrix.m[3][1], matrix.m[3][2], matrix.m[3][3])
                - matrix.m[0][1] * Matrix3x3.determinant(matrix.m[1][0], matrix.m[1][2], matrix.m[1][3], matrix.m[2][0], matrix.m[2][2], matrix.m[2][3], matrix.m[3][0], matrix.m[3][2], matrix.m[3][3])
                + matrix.m[0][2] * Matrix3x3.determinant(matrix.m[1][0], matrix.m[1][1], matrix.m[1][3], matrix.m[2][0], matrix.m[2][1], matrix.m[2][3], matrix.m[3][0], matrix.m[3][1], matrix.m[3][3])
                - matrix.m[0][3] * Matrix3x3.determinant(matrix.m[1][0], matrix.m[1][1], matrix.m[1][2], matrix.m[2][0], matrix.m[2][1], matrix.m[2][2], matrix.m[3][0], matrix.m[3][1], matrix.m[3][2]);

        return f;
    }

    public static Matrix4x4 inverse(float m00, float m01, float m02, float m03,
                                    float m10, float m11, float m12, float m13,
                                    float m20, float m21, float m22, float m23,
                                    float m30, float m31, float m32, float m33) {
        Matrix4x4 matrixOfMinors = new Matrix4x4();
        Matrix4x4 coFactor = new Matrix4x4();
        Matrix4x4 transposedCoFactor;
        Matrix4x4 result = new Matrix4x4();

        matrixOfMinors.m[0][0] = Matrix3x3.determinant(m11, m12, m13, m21, m22, m23, m31, m32, m33);
        matrixOfMinors.m[0][1] = Matrix3x3.determinant(m10, m12, m13, m20, m22, m23, m30, m32, m33);
        matrixOfMinors.m[0][2] = Matrix3x3.determinant(m10, m11, m13, m20, m21, m23, m30, m31, m33);
        matrixOfMinors.m[0][3] = Matrix3x3.determinant(m10, m11, m12, m20, m21, m22, m30, m31, m32);

        matrixOfMinors.m[1][0] = Matrix3x3.determinant(m01, m02, m03, m21, m22, m23, m31, m32, m33);
        matrixOfMinors.m[1][1] = Matrix3x3.determinant(m00, m02, m03, m20, m22, m23, m30, m32, m33);
        matrixOfMinors.m[1][2] = Matrix3x3.determinant(m00, m01, m03, m20, m21, m23, m30, m31, m33);
        matrixOfMinors.m[1][3] = Matrix3x3.determinant(m00, m01, m02, m20, m21, m22, m30, m31, m32);

        matrixOfMinors.m[2][0] = Matrix3x3.determinant(m01, m02, m03, m11, m12, m13, m31, m32, m33);
        matrixOfMinors.m[2][1] = Matrix3x3.determinant(m00, m02, m03, m10, m12, m13, m30, m32, m33);
        matrixOfMinors.m[2][2] = Matrix3x3.determinant(m00, m01, m03, m10, m11, m13, m30, m31, m33);
        matrixOfMinors.m[2][3] = Matrix3x3.determinant(m00, m01, m02, m10, m11, m12, m30, m31, m32);

        matrixOfMinors.m[3][0] = Matrix3x3.determinant(m01, m02, m03, m11, m12, m13, m21, m22, m23);
        matrixOfMinors.m[3][1] = Matrix3x3.determinant(m00, m02, m03, m10, m12, m13, m20, m22, m23);
        matrixOfMinors.m[3][2] = Matrix3x3.determinant(m00, m01, m03, m10, m11, m13, m20, m21, m23);
        matrixOfMinors.m[3][3] = Matrix3x3.determinant(m00, m01, m02, m10, m11, m12, m20, m21, m22);

        coFactor.m[0][0] =  matrixOfMinors.m[0][0];
        coFactor.m[0][1] = -matrixOfMinors.m[0][1];
        coFactor.m[0][2] =  matrixOfMinors.m[0][2];
        coFactor.m[0][3] = -matrixOfMinors.m[0][3];

        coFactor.m[1][0] = -matrixOfMinors.m[1][0];
        coFactor.m[1][1] =  matrixOfMinors.m[1][1];
        coFactor.m[1][2] = -matrixOfMinors.m[1][2];
        coFactor.m[1][3] =  matrixOfMinors.m[1][3];

        coFactor.m[2][0] =  matrixOfMinors.m[2][0];
        coFactor.m[2][1] = -matrixOfMinors.m[2][1];
        coFactor.m[2][2] =  matrixOfMinors.m[2][2];
        coFactor.m[2][3] = -matrixOfMinors.m[2][3];

        coFactor.m[3][0] = -matrixOfMinors.m[3][0];
        coFactor.m[3][1] =  matrixOfMinors.m[3][1];
        coFactor.m[3][2] = -matrixOfMinors.m[3][2];
        coFactor.m[3][3] =  matrixOfMinors.m[3][3];

        float determinant = Matrix4x4.determinant(m00, m01, m02, m03,
                                                  m10, m11, m12, m13,
                                                  m20, m21, m22, m23,
                                                  m30, m31, m32, m33);

        float oneOverDeterminant = 0.0f;

        if (determinant != 0.0f)
            oneOverDeterminant = 1.0f / determinant;

        transposedCoFactor = transpose(coFactor);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                result.m[i][j] = oneOverDeterminant * transposedCoFactor.m[i][j];
            }
        }

        return result;
    }

    public static Matrix4x4 inverse(Matrix4x4 output, Matrix4x4 matrix) {
        Matrix4x4 matrixOfMinors = new Matrix4x4();
        Matrix4x4 coFactor = new Matrix4x4();
        Matrix4x4 transposedCoFactor;
        Matrix4x4 result = new Matrix4x4();

        matrixOfMinors.m[0][0] = Matrix3x3.determinant(matrix.m[1][1], matrix.m[1][2], matrix.m[1][3], matrix.m[2][1], matrix.m[2][2], matrix.m[2][3], matrix.m[3][1], matrix.m[3][2], matrix.m[3][3]);
        matrixOfMinors.m[0][1] = Matrix3x3.determinant(matrix.m[1][0], matrix.m[1][2], matrix.m[1][3], matrix.m[2][0], matrix.m[2][2], matrix.m[2][3], matrix.m[3][0], matrix.m[3][2], matrix.m[3][3]);
        matrixOfMinors.m[0][2] = Matrix3x3.determinant(matrix.m[1][0], matrix.m[1][1], matrix.m[1][3], matrix.m[2][0], matrix.m[2][1], matrix.m[2][3], matrix.m[3][0], matrix.m[3][1], matrix.m[3][3]);
        matrixOfMinors.m[0][3] = Matrix3x3.determinant(matrix.m[1][0], matrix.m[1][1], matrix.m[1][2], matrix.m[2][0], matrix.m[2][1], matrix.m[2][2], matrix.m[3][0], matrix.m[3][1], matrix.m[3][2]);

        matrixOfMinors.m[1][0] = Matrix3x3.determinant(matrix.m[0][1], matrix.m[0][2], matrix.m[0][3], matrix.m[2][1], matrix.m[2][2], matrix.m[2][3], matrix.m[3][1], matrix.m[3][2], matrix.m[3][3]);
        matrixOfMinors.m[1][1] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][2], matrix.m[0][3], matrix.m[2][0], matrix.m[2][2], matrix.m[2][3], matrix.m[3][0], matrix.m[3][2], matrix.m[3][3]);
        matrixOfMinors.m[1][2] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][3], matrix.m[2][0], matrix.m[2][1], matrix.m[2][3], matrix.m[3][0], matrix.m[3][1], matrix.m[3][3]);
        matrixOfMinors.m[1][3] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][2], matrix.m[2][0], matrix.m[2][1], matrix.m[2][2], matrix.m[3][0], matrix.m[3][1], matrix.m[3][2]);

        matrixOfMinors.m[2][0] = Matrix3x3.determinant(matrix.m[0][1], matrix.m[0][2], matrix.m[0][3], matrix.m[1][1], matrix.m[1][2], matrix.m[1][3], matrix.m[3][1], matrix.m[3][2], matrix.m[3][3]);
        matrixOfMinors.m[2][1] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][2], matrix.m[0][3], matrix.m[1][0], matrix.m[1][2], matrix.m[1][3], matrix.m[3][0], matrix.m[3][2], matrix.m[3][3]);
        matrixOfMinors.m[2][2] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][3], matrix.m[1][0], matrix.m[1][1], matrix.m[1][3], matrix.m[3][0], matrix.m[3][1], matrix.m[3][3]);
        matrixOfMinors.m[2][3] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][2], matrix.m[1][0], matrix.m[1][1], matrix.m[1][2], matrix.m[3][0], matrix.m[3][1], matrix.m[3][2]);

        matrixOfMinors.m[3][0] = Matrix3x3.determinant(matrix.m[0][1], matrix.m[0][2], matrix.m[0][3], matrix.m[1][1], matrix.m[1][2], matrix.m[1][3], matrix.m[2][1], matrix.m[2][2], matrix.m[2][3]);
        matrixOfMinors.m[3][1] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][2], matrix.m[0][3], matrix.m[1][0], matrix.m[1][2], matrix.m[1][3], matrix.m[2][0], matrix.m[2][2], matrix.m[2][3]);
        matrixOfMinors.m[3][2] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][3], matrix.m[1][0], matrix.m[1][1], matrix.m[1][3], matrix.m[2][0], matrix.m[2][1], matrix.m[2][3]);
        matrixOfMinors.m[3][3] = Matrix3x3.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][2], matrix.m[1][0], matrix.m[1][1], matrix.m[1][2], matrix.m[2][0], matrix.m[2][1], matrix.m[2][2]);

        coFactor.m[0][0] =  matrixOfMinors.m[0][0];
        coFactor.m[0][1] = -matrixOfMinors.m[0][1];
        coFactor.m[0][2] =  matrixOfMinors.m[0][2];
        coFactor.m[0][3] = -matrixOfMinors.m[0][3];

        coFactor.m[1][0] = -matrixOfMinors.m[1][0];
        coFactor.m[1][1] =  matrixOfMinors.m[1][1];
        coFactor.m[1][2] = -matrixOfMinors.m[1][2];
        coFactor.m[1][3] =  matrixOfMinors.m[1][3];

        coFactor.m[2][0] =  matrixOfMinors.m[2][0];
        coFactor.m[2][1] = -matrixOfMinors.m[2][1];
        coFactor.m[2][2] =  matrixOfMinors.m[2][2];
        coFactor.m[2][3] = -matrixOfMinors.m[2][3];

        coFactor.m[3][0] = -matrixOfMinors.m[3][0];
        coFactor.m[3][1] =  matrixOfMinors.m[3][1];
        coFactor.m[3][2] = -matrixOfMinors.m[3][2];
        coFactor.m[3][3] =  matrixOfMinors.m[3][3];

        float determinant = Matrix4x4.determinant(matrix.m[0][0], matrix.m[0][1], matrix.m[0][2], matrix.m[0][3],
                                                  matrix.m[1][0], matrix.m[1][1], matrix.m[1][2], matrix.m[1][3],
                                                  matrix.m[2][0], matrix.m[2][1], matrix.m[2][2], matrix.m[2][3],
                                                  matrix.m[3][0], matrix.m[3][1], matrix.m[3][2], matrix.m[3][3]);

        float oneOverDeterminant = 0.0f;

        if (determinant != 0.0f)
            oneOverDeterminant = 1.0f / determinant;

        transposedCoFactor = transpose(coFactor);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                result.m[i][j] = oneOverDeterminant * transposedCoFactor.m[i][j];
            }
        }

        if (output == null)
            output = new Matrix4x4();

        output.m[0][0] = result.m[0][0]; output.m[0][1] = result.m[0][1]; output.m[0][2] = result.m[0][2]; output.m[0][3] = result.m[0][3];
        output.m[1][0] = result.m[1][0]; output.m[1][1] = result.m[1][1]; output.m[1][2] = result.m[1][2]; output.m[1][3] = result.m[1][3];
        output.m[2][0] = result.m[2][0]; output.m[2][1] = result.m[2][1]; output.m[2][2] = result.m[2][2]; output.m[2][3] = result.m[2][3];
        output.m[3][0] = result.m[3][0]; output.m[3][1] = result.m[3][1]; output.m[3][2] = result.m[3][2]; output.m[3][3] = result.m[3][3];

        return result;
    }


    public static Matrix4x4 perspectiveFOVRH(Matrix4x4 matrix, float fov, float aspectRatio, float nearZ, float farZ){
        float xScale = 0f;
        float yScale = MathCommon.cot(fov / 2f);

        if (aspectRatio != 0f)
            xScale = yScale / aspectRatio;

        if ((farZ - nearZ) != 0) {
            matrix.m[0][0] = xScale; matrix.m[0][1] = 0f; matrix.m[0][2] = 0f; matrix.m[0][3] = 0f;
            matrix.m[1][0] = 0f; matrix.m[1][1] = yScale; matrix.m[1][2] = 0f; matrix.m[1][3] = 0f;
            matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = farZ / (farZ - nearZ); matrix.m[2][3] = 1f;
            matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = -nearZ * farZ / (farZ - nearZ); matrix.m[3][3] = 0f;
        }

        return matrix;
    }

    public static Matrix4x4 perspectiveFOVLH(Matrix4x4 matrix, float fov, float aspectRatio, float nearZ, float farZ){
        float xScale = 0f;
        float yScale = MathCommon.cot(fov / 2f);

        if (aspectRatio != 0f)
            xScale = yScale / aspectRatio;

        if ((nearZ - farZ) != 0) {
            matrix.m[0][0] = xScale; matrix.m[0][1] = 0f; matrix.m[0][2]= 0f; matrix.m[0][3] = 0f;
            matrix.m[1][0] = 0f; matrix.m[1][1] = yScale; matrix.m[1][2] = 0f; matrix.m[1][3] = 0f;
            matrix.m[2][0] = 0f; matrix.m[2][1] = 0f; matrix.m[2][2] = farZ / (nearZ - farZ); matrix.m[2][3] = -1f;
            matrix.m[3][0] = 0f; matrix.m[3][1] = 0f; matrix.m[3][2] = nearZ * farZ / (nearZ - farZ); matrix.m[3][3] = 0f;
        }

        return matrix;
    }

    public static void printArray(float[] matrix){
        Log.d("printArray 0", String.valueOf(matrix[0]) + ", " + String.valueOf(matrix[1]) + ", " + String.valueOf(matrix[2]) + ", " + String.valueOf(matrix[3]));
        Log.d("printArray 1", String.valueOf(matrix[4]) + ", " + String.valueOf(matrix[5]) + ", " + String.valueOf(matrix[6]) + ", " + String.valueOf(matrix[7]));
        Log.d("printArray 2", String.valueOf(matrix[8]) + ", " + String.valueOf(matrix[9]) + ", " + String.valueOf(matrix[10]) + ", " + String.valueOf(matrix[11]));
        Log.d("printArray 3", String.valueOf(matrix[12]) + ", " + String.valueOf(matrix[13]) + ", " + String.valueOf(matrix[14]) + ", " + String.valueOf(matrix[15]));
    }
}
