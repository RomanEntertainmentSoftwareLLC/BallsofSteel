package math3D;

/**
 * Created by Roman Entertainment Software LLC on 5/3/2018.
 */
public class Quaternion3D {

    public Quaternion3D(){

    }
}
