package math2D;

/**
 * Created by Roman Entertainment Software LLC on 5/13/2018.
 */
public class Vector2D {
    public float x;
    public float y;

    public Vector2D(){

    }

    public Vector2D(float x, float y){
        this.x = x;
        this.y = y;
    }

    public Vector2D(Vertex2D vertexA, Vertex2D vertexB){
        this.x = vertexB.x - vertexA.x;
        this.y = vertexB.y - vertexA.y;
    }

    public Vector2D set(float x, float y){
        Vector2D result = new Vector2D();
        result.x = x;
        result.y = y;
        return result;
    }

    public Vector2D set(Vertex2D vertexA, Vertex2D vertexB){
        Vector2D result = new Vector2D();
        result.x = vertexB.x - vertexA.x;
        result.y = vertexB.y - vertexA.y;
        return result;
    }

    public float length()
    {
        return (float)Math.sqrt(x * x + y * y);
    }

    public float lengthSquared()
    {
        return x * x + y * y;
    }

    public void normalize()
    {
        float length = length();

        if (length != 0f){
            x /= length;
            y /= length;
        }

    }

    public float dotProduct(Vector2D vector)
    {
        return x * vector.x + y * vector.y;
    }

    public float dotProduct(Vertex2D vertex)
    {
        return x * vertex.x + y * vertex.y;
    }

    public static float dotProduct(Vector2D vectorA, Vector2D vectorB)
    {
        return vectorA.x * vectorB.x + vectorA.y * vectorB.y;
    }

    public static float dotProduct(Vertex2D vertexA, Vertex2D vertexB)
    {
        return vertexA.x * vertexB.x + vertexA.y * vertexB.y;
    }

    public Vector2D crossProduct()
    {
        Vector2D result = new Vector2D(-this.y, this.x);
        return result;
    }

    public void createNormal(Vector2D vector)
    {
        vector = crossProduct();
        vector.normalize();
        this.x = vector.x;
        this.y = vector.y;
    }

    Vector2D setNormal(Vector2D vector)
    {
        vector = crossProduct();
        vector.normalize();

        return vector;
    }
}
