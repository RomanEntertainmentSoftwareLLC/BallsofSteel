package math2D;

/**
 * Created by Roman Entertainment Software LLC on 4/27/2018.
 */
public class Vertex2D {
    public float x;
    public float y;

    public Vertex2D(){

    }

    public Vertex2D(float x, float y){
        this.x = x;
        this.y = y;
    }
}
