package romanentertainmentsoftware.ballsofsteel;

/**
 * Created by Roman Entertainment Software LLC on 5/3/2018.
 */
public class TextureCoord2D {
    public float tu;
    public float tv;

    public TextureCoord2D(){

    }

    public TextureCoord2D(float tu, float tv){
        this.tu = tu;
        this.tv = tv;
    }
}
