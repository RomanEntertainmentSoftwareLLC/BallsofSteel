package romanentertainmentsoftware.ballsofsteel;

import static android.opengl.GLES20.GL_COLOR_BUFFER_BIT;
import static android.opengl.GLES20.GL_DEPTH_BUFFER_BIT;
import static android.opengl.GLES20.GL_STENCIL_BUFFER_BIT;
import static android.opengl.GLES20.glClear;
import static android.opengl.GLES20.glUseProgram;

public class Bloom {

    public Bloom() {

    }

    public static void createGaussianWeights(BlurBuffer buffer) {
        float sum = 0.0f;
        float x;
        float threshold_squared = buffer.sigma * buffer.sigma;
        float two_times_threshold_squared = 2.0f * threshold_squared;
        buffer.mu = (float)(buffer.kernel_diameter - 1) / 2.0f;

        // Calculate Gaussian weights based on the kernel diameter
        for (int i = 0; i < buffer.kernel_diameter; i++) {
            x = (i - ((buffer.kernel_diameter - 1) / 2.0f));
            buffer.weights[i] = (1.0f / (float)Math.sqrt(Math.PI * two_times_threshold_squared)) * (float)Math.exp(-1.0 * (x * x) / two_times_threshold_squared);
            sum += buffer.weights[i];
        }

        // Normalize the weights
        for (int i = 0; i < buffer.kernel_diameter; i++) {
            buffer.weights[i] /= sum;
        }
    }

    public static void renderToExposureToneMappingFrameBuffer() {
        Render.exposureToneMappingFrameBuffer.bind();
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
        glUseProgram(Render.programExposureToneMapping);
        Render.exposureToneMappingBuffer.update();

        Render.exposure_tone_mapped_polygon.bindData();
        Render.exposure_tone_mapped_polygon.position.x = 0.0f;
        Render.exposure_tone_mapped_polygon.position.y = 0.0f;
        Render.exposure_tone_mapped_polygon.updateMatrices(Render.projectionMatrix2D, Render.camera[0].aspectRatio, 0f);
        Render.exposure_tone_mapped_polygon.setTexture(Render.frameBuffer.texture);
        Render.exposure_tone_mapped_polygon.rgba(1f,1f,1f, 1f);
        Render.exposure_tone_mapped_polygon.draw();

        Render.exposureToneMappingFrameBuffer.unbind();
    }
}
