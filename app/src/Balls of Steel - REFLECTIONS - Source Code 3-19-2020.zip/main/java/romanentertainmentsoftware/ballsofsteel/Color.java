package romanentertainmentsoftware.ballsofsteel;

/**
 * Created by Roman Entertainment Software LLC on 5/6/2018.
 */
public class Color {
    public float red;
    public float green;
    public float blue;
    public float alpha;

    public Color(){

    }
}
